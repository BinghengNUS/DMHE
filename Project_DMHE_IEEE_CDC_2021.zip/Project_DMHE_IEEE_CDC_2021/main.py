"""
This is the main function that trains the DMHE and evaluates its performance.
The results correspond to the case of initial condition 1 in Section V of the CDC paper.
You can obtain results of other three cases by changing the initial conditions in line 270.
The curves of gamma1 and 2 in learning may be subject to change due to the random noise of the disturbances, 
but their optimal values after learning should be stable at around 0.95 and 0.2, respectively.
----------------------------------------------------------------------------
Wang, Bingheng, 24 Dec. 2020, at Advanced Control Lab, ECE Dept. NUS
It was modified on 31, Aug. 2021.
Should you have any question, please feel free to contact the author via:
wangbingheng@u.nus.edu
"""
import UavEnv
import Robust_Flight
from casadi import *
import time as TM
import numpy as np
import matplotlib.pyplot as plt
import uavNN
import torch
from numpy import linalg as LA
import math


"""---------------------------------Learn or Evaluate?-------------------------------------"""
train = True
"""---------------------------------Type of disturbance?-----------------------------------"""
constant_dis = False

"""---------------------------------Load environment---------------------------------------"""
Sys_para = np.array([1.8, 0.018343, 0.019718, 0.032193, 0.21, 1.024e-7, 1.303e-9])
u_max = 12000 # 12000 pm, the maximum rotation speed per minute
u_min = 0
U_upper = np.array([[u_max**2, u_max**2, u_max**2, u_max**2]]).T
U_lower = np.array([[u_min, u_min, u_min, u_min]]).T
IGE_para = np.array([0.44, 1.8, 0.1])

# Simulation time-step
T_step = 5e-3
# Sampling time-step
dt_sample = 1e-2
uav = UavEnv.quadrotor(Sys_para, IGE_para, dt_sample)
uav.Model()
# Initial states
r_I0 = np.array([[0, 0, 0]]).T # column vector
p_I0 = np.array([[0, 0, -0.05]]).T
vp_I0= np.array([[0, 0, 0]]).T
v_I0 = np.array([[0, 0, 0]]).T
df_I0 = np.array([[0, 0, 0]]).T
Euler_0 = np.array([[0, 0, 0]]).T
R_Bv0, R_Bd0 = uav.dir_cosine(Euler_0)
dR_Bd0 = np.zeros((3, 3))
w_B0 = np.array([[0, 0, 0]]).T
dt_B0 = np.array([[0, 0, 0]]).T  # disturbance torque in body frame
state0 = np.vstack((r_I0, v_I0, R_Bv0, w_B0))
Xmhe0 = np.vstack((r_I0, v_I0, df_I0, R_Bv0, w_B0, dt_B0)) # CANNOT define the type as vertcat!!!!

# Load trajectory data
filename = 'waypoints'
traj_waypoints = np.loadtxt(filename)
horizon = 25 # previous 30
# Time interval of taking-off
t_end = 5
# Time interval of an episode
t_ep  = 4*dt_sample * (np.size(traj_waypoints, 0))
t_epv = 4*dt_sample * (np.size(traj_waypoints, 0))
# Iteration number
N = int(t_ep / T_step)
N_ev = int(t_epv/T_step)
# Learning rate
lr_nn0  = 1e-4

# Total training times
N_train = 50
# time constant in low-pass filter
fc  = int(1/dt_sample)/50 # cutoff frequency of LPF
tau = 1/(2*np.pi*fc)
"""---------------------------------Define parameterization model-----------------------------"""
# Define neural network for process noise
D_in, D_h, D_out_p = 22, 64, 50
model_QR = uavNN.Net(D_in, D_h, D_out_p)
P_min = 0.01
P_max = 10
gammar_min = 0.5
gammar_max = 1
gammaq_min = 0.5
gammaq_max = 1
R_min = 10
R_max = 1e2
Q_min = 10
Q_max = 1e2
para_bound_p  = (P_max-P_min)*np.ones((1, 24))
para_bound_gr = (gammar_max-gammar_min)*np.ones((1, 1))
para_bound_r  = (R_max-R_min)*np.ones((1, 18))
para_bound_gq = (gammaq_max-gammaq_min)*np.ones((1, 1))
para_bound_q  = (Q_max-Q_min)*np.ones((1, 6))
para_bound = np.hstack((para_bound_p, para_bound_gr, para_bound_r, para_bound_gq, para_bound_q))
para_jaco = np.diag(para_bound[0])


def para(para_bar):
    P_min = 0.01
    P_max = 10
    gammar_min = 0.5
    gammar_max = 1
    gammaq_min = 0.5
    gammaq_max = 1
    R_min = 10
    R_max = 1e2
    Q_min = 10
    Q_max = 1e2
    tunable = np.zeros((1, 50))
    for i in range(50):
        tunable[0, i] = para_bar[i, 0]  # convert tensor to array
    tunable_para = np.zeros((1, 50))
    for i in range(24):
        tunable_para[0, i] = P_min + (P_max - P_min) * tunable[0, i]
    for i in range(18):
        tunable_para[0, i + 25] = R_min + (R_max - R_min) * tunable[0, i + 25]
    for i in range(6):
        tunable_para[0, i + 44] = Q_min + (Q_max - Q_min) * tunable[0, i + 44]
    tunable_para[0, 24] = gammar_min + (gammar_max - gammar_min) * tunable[0, 24]
    tunable_para[0, 43] = gammaq_min + (gammaq_max - gammaq_min) * tunable[0, 43]
    return tunable_para

# Parameterize control gain
D_in, D_h, D_out = 36, 50, 12
model_gain = uavNN.NetCtrl(D_in, D_h, D_out)
gp_min = 1e-1  # lower bound of position control gain
gp_max = 20  # upper bound of position control gain
gv_min = 1e-1 # lower bound of velocity gain
gv_max = 10 # 10 upper bound of velocity gain
ga_min = 1e-1 # lower bound of attitude gain
ga_max = 10 # 10 upper bound of attitude gain
ctrl_gain_jaco = np.diag([(gp_max-gp_min), (gp_max-gp_min), (gp_max-gp_min),
                          (gv_max-gv_min), (gv_max-gv_min), (gv_max-gv_min),
                          (ga_max-ga_min), (ga_max-ga_min), (ga_max-ga_min),
                          (ga_max-ga_min), (ga_max-ga_min), (ga_max-ga_min)])
def control_gain(nn_gain):
    ctrl_gain = np.zeros((1, 12))
    for i in range(12):
        if i<=2:
            ctrl_gain[0, i] = gp_min + (gp_max-gp_min)*nn_gain[i, 0]
        elif i<6:
            ctrl_gain[0, i] = gv_min + (gv_max - gv_min) * nn_gain[i, 0]
        else:
            ctrl_gain[0, i] = ga_min + (ga_max-ga_min)*nn_gain[i, 0]
    return ctrl_gain


"""---------------------------------Define reference trajectory-----------------------------"""
# Target point for take-off
x_t, y_t, z_t = 0, 0, -2
dx_t, dy_t, dz_t = 0, 0, 0
ddx_t, ddy_t, ddz_t = 0, 0, 0
target = np.hstack((x_t, dx_t, ddx_t, y_t, dy_t, ddy_t, z_t, dz_t, ddz_t))

def polynomial_ref(t_end, target, initial_state):
    x_0, dx_0, ddx_0 = initial_state[0], 0, 0
    y_0, dy_0, ddy_0 = initial_state[1], 0, 0
    z_0, dz_0, ddz_0 = -0.1, 0, 0
    x_t, dx_t, ddx_t = target[0], target[1], target[2]
    y_t, dy_t, ddy_t = target[3], target[4], target[5]
    z_t, dz_t, ddz_t = target[6], target[7], target[8]
    x_con = np.vstack((x_0, dx_0, ddx_0, x_t, dx_t, ddx_t))
    y_con = np.vstack((y_0, dy_0, ddy_0, y_t, dy_t, ddy_t))
    z_con = np.vstack((z_0, dz_0, ddz_0, z_t, dz_t, ddz_t))
    A_p   = np.array([[0, 0, 0, 0, 0, 1],
                      [0, 0, 0, 0, 1, 0],
                      [0, 0, 0, 2, 0, 0],
                      [t_end**5, t_end**4, t_end**3, t_end**2, t_end, 1],
                      [5*t_end**4, 4*t_end**3, 3*t_end**2, 2*t_end, 1, 0],
                      [20*t_end**3, 12*t_end**2, 6*t_end, 2, 0, 0]])
    Coeff_x = np.matmul(LA.inv(A_p), x_con)
    Coeff_y = np.matmul(LA.inv(A_p), y_con)
    Coeff_z = np.matmul(LA.inv(A_p), z_con)
    return Coeff_x, Coeff_y, Coeff_z

def Reference(Coeff_x, Coeff_y, Coeff_z, time, t_end, target):
    # Position reference as a polynomial of time
    p_t  = np.array([[time**5, time**4, time**3, time**2, time, 1]])
    v_t  = np.array([[5*time**4, 4*time**3, 3*time**2, 2*time, 1, 0]])
    a_t  = np.array([[20*time**3, 12*time**2, 6*time, 2, 0, 0]])
    if time <= t_end:
        ref_p = np.array([[np.matmul(p_t, Coeff_x)[0, 0], np.matmul(p_t, Coeff_y)[0, 0], np.matmul(p_t, Coeff_z)[0, 0]]]).T
        ref_v = np.array([[np.matmul(v_t, Coeff_x)[0, 0], np.matmul(v_t, Coeff_y)[0, 0], np.matmul(v_t, Coeff_z)[0, 0]]]).T
        ref_a = np.array([[np.matmul(a_t, Coeff_x)[0, 0], np.matmul(a_t, Coeff_y)[0, 0], np.matmul(a_t, Coeff_z)[0, 0]]]).T
    else:
        ref_p = np.array([[target[0], target[3], target[6]]]).T
        ref_v = np.array([[target[1], target[4], target[7]]]).T
        ref_a = np.array([[target[2], target[5], target[8]]]).T

    b1_d = np.array([[1, 0, 0]]).T
    reference = {"ref_p": ref_p,
                 "ref_v": ref_v,
                 "ref_a": ref_a,
                 "b1_d": b1_d}
    return reference


def weightforlearning(k_lp, k_lg1, k_lr, k_lg2, k_lq):
    lr_weight = np.array([k_lp, k_lp, k_lp, k_lp, k_lp, k_lp,
                          k_lp, k_lp, k_lp, k_lp, k_lp, k_lp,
                          k_lp, k_lp, k_lp, k_lp, k_lp, k_lp,
                          k_lp, k_lp, k_lp, k_lp, k_lp, k_lp,
                          k_lg1,
                          k_lr, k_lr, k_lr, k_lr, k_lr, k_lr,
                          k_lr, k_lr, k_lr, k_lr, k_lr, k_lr,
                          k_lr, k_lr, k_lr, k_lr, k_lr, k_lr,
                          k_lg2,
                          k_lq, k_lq, k_lq, k_lq, k_lq, k_lq])
    return lr_weight

"""---------------------------------Define controller---------------------------------------"""
# Controller
nn_gain0 = model_gain(np.zeros((36, 1)))
ctrl_gain0 = control_gain(nn_gain0)
GeoCtrl = Robust_Flight.Controller(Sys_para, uav.X, uav.Xmhe)
# Random initial x and y postions
P_xy0 = np.random.normal(0, 0, 2)
Coeff_x, Coeff_y, Coeff_z = polynomial_ref(t_end, target, P_xy0)
time0 = 0
ref0  = Reference(Coeff_x, Coeff_y, Coeff_z, time0, t_end, target)
ref_p0, ref_v0, ref_a0, b1_d0 = ref0['ref_p'], ref0['ref_v'], ref0['ref_a'], ref0['b1_d']
R_Bdin, Tfin, e_x, e_v, fd = GeoCtrl.position_ctrl(ctrl_gain0, state0, ref_p0, ref_v0, ref_a0, b1_d0, df_I0)
dR_Bdin, ddR_Bdin = np.zeros((3, 3)), np.zeros((3, 3))
tau_cin, w_Bdin, e_R, e_w, error_func  = GeoCtrl.attitude_ctrl(dR_Bdin, ddR_Bdin, dt_B0)
ctrl0 = GeoCtrl.ctrl_mapping(Tfin, tau_cin)

"""---------------------------------Define MHE----------------------------------------------"""

uavMHE = Robust_Flight.MHE(Sys_para, horizon, dt_sample)
uavMHE.SetStateVariable(uav.Xmhe)
uavMHE.SetOutputVariable(uav.output)
uavMHE.SetControlVariable(uav.ctrl)
uavMHE.SetRotationVariable(uav.R_B)
uavMHE.SetNoiseVariable(uav.noise)
uavMHE.SetModelDyn(uav.DynEuler)
uavMHE.SetCostDyn()


"""---------------------------------Define DMHE----------------------------------------------"""
uavDMHE = Robust_Flight.Auxiliary_MHE(uav.Xmhe.numel(), uav.X.numel(), dt_sample, uav.XdotDMHEeuler, GeoCtrl.ctrl_gain_v,
                                      GeoCtrl.ctrl_gain_v.numel(), GeoCtrl.ref_v, GeoCtrl.ex_v, GeoCtrl.ev_v,
                                      uav.output, uav.ctrl, GeoCtrl.u_v, uav.noise, uav.Xmhe, GeoCtrl.mass, GeoCtrl.J_B,
                                      uav.R_B, GeoCtrl.error_func_v, GeoCtrl.ew_v, GeoCtrl.eR_v)

"""---------------------------------Training process-----------------------------"""
# Estimated disturbance
ratio = T_step/dt_sample
ratio_inv = int(1/ratio)
Df_Imh = np.zeros((3, int(N_ev/ratio_inv)+1))
Dt_Bmh = np.zeros((3, int(N_ev/ratio_inv)+1))
# Ground truth
Dis_t = np.zeros((6, int(N_ev/ratio_inv)+1))
D_G   = np.zeros((6, N_ev+1))
# Simulation record
r_Is = np.zeros((3, N_ev+1))
p_Is = np.zeros((3, N_ev+1))
v_Is = np.zeros((3, N_ev+1))
Euler = np.zeros((3, N_ev+1))
w_Bs = np.zeros((3, N_ev+1))

# Tunable parameters
Tunable_para = np.zeros(((int(N_ev/ratio_inv)+1), D_out_p))
# Control gain
Control_gain = np.zeros(((int(N_ev/ratio_inv)), 12))
# Loss for training and episode
LOSS = np.zeros((N_train, (int(N/ratio_inv)-horizon)))
J_loss = np.zeros((int(N/ratio_inv)-horizon))
# We can change the initial values of the tuning parameters here
tunable_para0 = np.array([[5,5,5,5,5,5,5,5,
                                  5,5,5,5,5,5,5,5,
                                  5,5,5,5,5,5,5,5,
                                  0.4,
                                  50,50,50,50,50,50,
                                  50,50,50,50,50,50,
                                  50,50,50,50,50,50,
                                  0.8,
                                  50,50,50,50,50,50]]) # p=0.5, gamma1 =0.65

# tunable_p0 = 0.2*np.ones((1,50))

def Train(tunable_para0):
    # Loss function
    Loss = []
    # Training times
    Gamma1 = []
    Gamma2 = []
    Time_t = []
    k_train = 0
    mean_loss0 = 0
    delta_cost = 1
    eps     = 0.2
    i       = 0
    # tracking performance in training
    Position = []
    Error = []
    # timing
    grad_time = []
    
    while delta_cost >= eps:
        # Initial time
        time = 0

        # Initial states
        P_xy0 = np.random.normal(0, 0, 2)
        print('P_xy0=', P_xy0)
        r_I0  = np.array([[P_xy0[0], P_xy0[1], 0]]).T
        state = np.vstack((r_I0, v_I0, R_Bv0, w_B0))
        x_hatmh = np.vstack((r_I0, v_I0, df_I0, R_Bv0, w_B0, dt_B0))
        xmhe_traj = x_hatmh
        R_Bd  = R_Bd0
        dR_Bd = dR_Bd0
        # Control force and torque list
        ctrl_f = []
        # Control list
        ctrl = []
        #motor speed
        speed = []
        speed0 = np.sqrt(Sys_para[0]*9.8/(4*Sys_para[5]))/u_max*np.ones((4,1))
        speed += [speed0]
        # Control gain list
        Ctrl_Gain =[]
        # Measurement list
        Y = []
        # Tracking error list
        track_e = []
        track_e += [np.zeros((10, 1))]
        # add measurement noise
        noise = np.random.normal(0, 1e-3, uav.X.numel())
        Noise = np.zeros((1, 18))
        for iN in range(18):
            Noise[0, iN] = noise[iN]
        state_m = state.T + Noise
        state_m = state_m.T
        # sample the measurement and ground truth
        y_p = state_m[0:6, 0]
        y_p = np.reshape(y_p, (6, 1))
        Y += [state_m]
        Y_p = []
        Y_p += [y_p]
        # Initialize the reference trajectory
        kr = 0

        R_Bd_h = np.transpose(R_Bv0)
        w_Bd   = w_B0

        # Initialize the tunable parameters
        # tunable_p    = tunable_p0
        tunable_para = tunable_para0
        print('learned', i, 'tunable_para0=', tunable_para)
        # Reference list
        Ref = []
        # Rotation list
        R_B = []
        # Index for sampling
        k = 0
        # Flag for breaking the episode
        flag = 0
        # Sum of loss
        sum_loss = 0.0
        # Sum of time
        sum_time = 0.0
        # index for LOSS in each episode
        j_loss = 0
        a_I_p = []
        a_I_new = np.zeros((3, 1))
        for ia in range(20):
            a_I_p += [a_I_new]

        dR_lp = np.zeros((3, 3))
        ddR_lp = np.zeros((3, 3))
        # record position tracking performance for each episode in training
        position = np.zeros((3, N))
        error = np.zeros((4, N))  # position tracking error plus attitude error

        for j in range(N):
            if j % 8 == 0:
                if kr <= (np.size(traj_waypoints, 0)-1):
                    ref_p = np.array([[traj_waypoints[kr, 0], traj_waypoints[kr, 1], -traj_waypoints[kr, 2]]]).T
                    ref_v = np.array([[traj_waypoints[kr, 3], traj_waypoints[kr, 4], -traj_waypoints[kr, 5]]]).T
                    ref_dv = np.array([[traj_waypoints[kr, 6], traj_waypoints[kr, 7], -traj_waypoints[kr, 8]]]).T
                    ref_pva  = np.vstack((ref_p, ref_v, np.transpose(R_Bd_h), w_Bd))
                    b1_d = np.array([[1, 0, 0]]).T
                else:
                    ref_p = np.array([[traj_waypoints[-1, 0], traj_waypoints[-1, 1], -traj_waypoints[-1, 2]]]).T
                    ref_v = np.array([[traj_waypoints[-1, 3], traj_waypoints[-1, 4], -traj_waypoints[-1, 5]]]).T
                    ref_dv = np.array([[traj_waypoints[-1, 6], traj_waypoints[-1, 7], -traj_waypoints[-1, 8]]]).T
                    ref_pva = np.vstack((ref_p, ref_v, np.transpose(R_Bd_h), w_Bd))
                    b1_d = np.array([[1, 0, 0]]).T
                kr += 1
            # Coeff_x, Coeff_y, Coeff_z = polynomial_ref(t_end, target, P_xy0)
            # ref = Reference(Coeff_x, Coeff_y, Coeff_z, time, t_end, target)
            # ref_p, ref_v, ref_dv, b1_d = ref['ref_p'], ref['ref_v'], ref['ref_a'], ref['b1_d']
            ref_pva = np.vstack((ref_p, ref_v, np.transpose(R_Bd_h), w_Bd))
            if (j % ratio_inv) == 0:
                # Solve MHE to obtain the estimated state trajectory within a horizon
                # TUNable_para[k_train, :] = tunable_para
                k_train += 1
                opt_sol = uavMHE.MHEsolver(Y, x_hatmh, xmhe_traj, ctrl, tunable_para, k, speed)
                xmhe_traj = opt_sol['state_traj_opt']
                costate_traj = opt_sol['costate_traj_opt']
                noise_traj = opt_sol['noise_traj_opt']
                # Establish the auxiliary MHE system
                auxSys = uavMHE.GetAuxSys(xmhe_traj, costate_traj, noise_traj, tunable_para, Y, ctrl, speed)
                matA, matB, matH = auxSys['matA'], auxSys['matB'], auxSys['matH']
                matD, matE, matF = auxSys['matD'], auxSys['matE'], auxSys['matF']
                matG             = auxSys['matG']
                # Solve the auxiliary MHE system to obtain the gradient
                start_time = TM.time()
                gra_opt = uavDMHE.AuxMHESolver(matA, matB, matD, matE, matF, matH, matG, tunable_para, Y, speed)
                gradtime = TM.time() - start_time
                print("--- %s seconds ---" % gradtime)
                sum_time += gradtime

                X_opt = gra_opt['state_gra_traj']
                if time>(horizon*dt_sample):
                    # Update x_hatmh based on xmhe_traj
                    for ix in range(len(x_hatmh)):
                        x_hatmh[ix] = xmhe_traj[1, ix]
                else:
                    for ix in range(len(x_hatmh)):
                        x_hatmh[ix] = xmhe_traj[0, ix]

                # Position control
                df_Imh = np.transpose(xmhe_traj[-1, 6:9])
                df_Imh = np.reshape(df_Imh, (3, 1))
                dt_Bmh = np.transpose(xmhe_traj[-1, 21:24])
                dt_Bmh = np.reshape(dt_Bmh, (3, 1))
                ctrl_gain = np.array([[30, 22, 21, 9, 9, 9, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2]])
                # tunable_para = para(tunable_p.T)
                print('sample=', k,'p1=', tunable_para[0, 0], 'gamma1=', tunable_para[0, 24], 'r1=', tunable_para[0, 25], 'gamma2=', tunable_para[0, 43], 'q1=', tunable_para[0, 44], 'ref.x=', ref_p.T[0, 0], 'ref.z=', ref_p.T[0, 2])
                feedback = np.hstack((xmhe_traj[-1,0:6], xmhe_traj[-1,9:21]))
                feedback = np.reshape(feedback, (18, 1))
                R_Bd_next, Tf, e_x, e_v, fd = GeoCtrl.position_ctrl(ctrl_gain, feedback, ref_p, ref_v, ref_dv, b1_d, df_Imh)
                dR_Bd_nolp = (R_Bd_next - R_Bd) / dt_sample
                R_Bd = R_Bd_next  # update R_Bd0 for computing dR_Bd in the next iteration
                dR_Bd_next = (dR_Bd_nolp + (tau / dt_sample) * dR_lp) / (1 + tau / dt_sample)
                dR_lp = dR_Bd_next
                ddR_Bd_nolp = (dR_Bd_next - dR_Bd) / dt_sample
                dR_Bd = dR_Bd_next
                ddR_Bd_next = (ddR_Bd_nolp + (tau / dt_sample) * ddR_lp) / (1 + tau / dt_sample)
                ddR_lp = ddR_Bd_next
                DR_Bd_next = np.zeros((3, 3))
                DDR_Bd_next = np.zeros((3, 3))
                for ir in range(3):
                    for jr in range(3):
                        DR_Bd_next[ir, jr] = dR_Bd_next[ir, jr]
                for ir in range(3):
                    for jr in range(3):
                        DDR_Bd_next[ir, jr] = ddR_Bd_next[ir, jr]
                # Attitude control
                tau_c, w_Bd, e_R, e_w, error_func = GeoCtrl.attitude_ctrl(DR_Bd_next, DDR_Bd_next, dt_Bmh)

                # Map the control force and torque to the square of the rotor speed
                u = GeoCtrl.ctrl_mapping(Tf, tau_c)
                # Limit the rotor speed
                u = np.clip(u, U_lower, U_upper)

                # Store tracking error
                error_track = np.vstack((e_x, e_v, error_func, e_w))
                track_e += [error_track]
                Ctrl_Gain += [ctrl_gain]
                speed += [np.sqrt(u)/u_max]
                # U_lower = 0.9*U_lower
                ctrl_f += [fd]
                ctrl += [u]
                # Store the rotation
                R_bc = np.array([
                    [Y[-1][6, 0], Y[-1][7, 0], Y[-1][8, 0]],
                    [Y[-1][9, 0], Y[-1][10, 0], Y[-1][11, 0]],
                    [Y[-1][12, 0], Y[-1][13, 0], Y[-1][14, 0]]]
                )
                R_B  += [R_bc]
                # Store the reference
                R_Bd_h = np.array([[R_Bd[0, 0], R_Bd[0, 1], R_Bd[0, 2],
                                    R_Bd[1, 0], R_Bd[1, 1], R_Bd[1, 2],
                                    R_Bd[2, 0], R_Bd[2, 1], R_Bd[2, 2]]])
                ref = np.hstack((np.transpose(ref_p), np.transpose(ref_v), R_Bd_h, np.transpose(w_Bd)))
                Ref  += [ref]
                print('b1d=',np.array([[R_Bd[0, 0],R_Bd[1, 0],R_Bd[2, 0]]]), 'b3_d=',np.array([[R_Bd[0, 2],R_Bd[1, 2],R_Bd[2, 2]]]))

            # store position and tracking error
            pos_c = np.reshape(Y[-1][0:3], (3, 1))
            position[:, j:j + 1] = pos_c
            error[:, j:j + 1] = np.vstack((e_x, error_func))
            Tunable_para[j:j+1,:] = tunable_para
            # Take a next step from the environment
            if time <=2:
                noise = np.random.normal(0, 0.1, 1)
                aero_para = np.array([[0.2+0.1*noise[0], 0.2+0.1*noise[0], 1*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0]]]).T
            elif time<=4 and time>2:
                noise = np.random.normal(0, 0.1, 1)
                aero_para = -np.array([[0.2+0.1*noise[0], 0.2+0.1*noise[0], 1*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0]]]).T
            elif time <= 8 and time > 4:
                noise = np.random.normal(0, 0.1, 1)
                aero_para = 1 * np.array([[0.25 * math.sin(0.5 * math.pi * time) + 0.25 * noise[0],
                                           0.25 * math.sin(0.5 * math.pi * time) + 0.25 * noise[0],
                                           2 * math.sin(0.5 * math.pi * time) + 1 * noise[0],
                                           0.05 * math.sin(0.5 * math.pi * time) + 0.02 * noise[0],
                                           0.05 * math.sin(0.5 * math.pi * time) + 0.02 * noise[0],
                                           0.01 * math.sin(0.5 * math.pi * time) + 0.01 * noise[0]]]).T
            elif time <= 12 and time > 8:
                noise = np.random.normal(0, 0.1, 1)
                aero_para = 2 * np.array([[0.25 * math.sin(0.5 * math.pi * time) + 0.25 * noise[0],
                                           0.25 * math.sin(0.5 * math.pi * time) + 0.25 * noise[0],
                                           2 * math.sin(0.5 * math.pi * time) + 1 * noise[0],
                                           0.05 * math.sin(0.5 * math.pi * time) + 0.02 * noise[0],
                                           0.05 * math.sin(0.5 * math.pi * time) + 0.02 * noise[0],
                                           0.01 * math.sin(0.5 * math.pi * time) + 0.008 * noise[0]]]).T
            elif time<=14 and time>12:
                noise = np.random.normal(0, 0.1, 1)
                aero_para = np.array([[0.2+0.1*noise[0], 0.2+0.1*noise[0], 6+2*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0]]]).T
            elif time<=16 and time>14:
                noise = np.random.normal(0, 0.05, 1)
                aero_para = -np.array([[0.2+0.1*noise[0], 0.2+0.1*noise[0], 2+2*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0]]]).T
            # elif time<=15 and time>14:
            #     noise = np.random.normal(0, 0.1, 1)
            #     aero_para = np.array([[0.2+0.1*noise[0], 0.2+0.1*noise[0], 6+2*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0]]]).T
            else:
                aero_para = np.zeros((6, 1))
            dis = uav.Aerodynamics(state, ctrl[-1], aero_para)

            # print('sample=', k, 'Tension=', T)
            print('sample=', k, 'Dist_x=', dis[3, 0], 'dt_Imh_x=', dt_Bmh[0, 0], 'Dis_x=', dis[0, 0], 'df_Imh_x=', df_Imh[0, 0], 'Dis_z=', dis[2, 0], 'df_Imh_z=', df_Imh[2, 0])
            zeros_rotor = np.where(ctrl[-1]==0)[0]
            if np.size(zeros_rotor)>=2:
                flag += 1
            else:
                flag = 0
            if flag >= 20:
                break
            else:
                loss_add = 0
            output = uav.step(state, ctrl[-1], dis, T_step)
            # Update state
            state = output['state_new']
            a_I_next = output['a_I_new']
            if (j % ratio_inv) == 0:
                k += 1
                # Take measurement
                noise = np.random.normal(0, 1e-3, uav.X.numel())
                Noise = np.zeros((1, 18))
                for iN in range(18):
                    Noise[0, iN] = noise[iN]
                state_m = state.T + Noise
                state_m = state_m.T
                # sample the measurement and ground truth
                Y += [state_m]

                # Compute the gradient of loss
                
                dp, loss_track = uavDMHE.ChainRule(Ref, xmhe_traj,X_opt)
                
                # Initial learning rate
                lr_nn = lr_nn0
                k_lp  = 1e2
                k_lg1 = 1
                k_lr  = 1e3
                k_lg2 = 1
                k_lq  = 1e3
                weight_lr = np.diag(weightforlearning(k_lp, k_lg1, k_lr, k_lg2, k_lq))

                if i >0 :
                    tunable_paranew = tunable_para - lr_nn * np.matmul(dp, weight_lr)
                    gamma1     = tunable_para[0, 24]
                    gamma2     = tunable_para[0, 43]
                    gamma1_new = tunable_paranew[0, 24]
                    gamma2_new = tunable_paranew[0, 43]
                    Gamma1    += [gamma1]
                    Gamma2    += [gamma2]
                    min_P      = np.amin(tunable_paranew[0, 0:24])
                    min_R      = np.amin(tunable_paranew[0, 25:43])
                    min_Q      = np.amin(tunable_paranew[0, 44:50])
                    # We apply the line search algorithm to adjust the learning rates such that the parameters' boundaries are guaranteed 
                    while min_P <=0.01:
                        k_lp = 0.1*k_lp
                        weight_lr = np.diag(weightforlearning(k_lp, k_lg1, k_lr, k_lg2, k_lq))
                        tunable_paranew = tunable_para - lr_nn * np.matmul(dp, weight_lr)
                        min_P      = np.amin(tunable_paranew[0, 0:24])

                    while gamma1_new <= 0.2 or gamma1_new >= 1:
                        k_lg1 = 0.1*k_lg1
                        weight_lr = np.diag(weightforlearning(k_lp, k_lg1, k_lr, k_lg2, k_lq))
                        tunable_paranew = tunable_para - lr_nn * np.matmul(dp, weight_lr)
                        gamma1_new = tunable_paranew[0, 24]
                        delta1     = abs(gamma1-gamma1_new)

                    while min_R <= 0.01:
                        k_lr = 0.1*k_lr
                        weight_lr = np.diag(weightforlearning(k_lp, k_lg1, k_lr, k_lg2, k_lq))
                        tunable_paranew = tunable_para - lr_nn * np.matmul(dp, weight_lr)
                        min_R      = np.amin(tunable_paranew[0, 25:43])
                    
                    while gamma2_new <= 0.2 or gamma2_new >=1:
                        k_lg2 = 0.1*k_lg2
                        weight_lr = np.diag(weightforlearning(k_lp, k_lg1, k_lr, k_lg2, k_lq))
                        tunable_paranew = tunable_para - lr_nn * np.matmul(dp, weight_lr)
                        gamma2_new = tunable_paranew[0, 43]
                        delta2     = abs(gamma2-gamma2_new)

                    while min_Q <= 0.01:
                        k_lq = 0.1*k_lq
                        weight_lr = np.diag(weightforlearning(k_lp, k_lg1, k_lr, k_lg2, k_lq))
                        tunable_paranew = tunable_para - lr_nn * np.matmul(dp, weight_lr)
                        min_Q      = np.amin(tunable_paranew[0, 44:50])

                    weight_lr = np.diag(weightforlearning(k_lp, k_lg1, k_lr, k_lg2, k_lq))
                    tunable_para = tunable_para - lr_nn * np.matmul(dp, weight_lr)
                tunable_para0 = tunable_para
                # Sum the loss
                loss_track = np.reshape(loss_track, (1))
                sum_loss += loss_track
                if time>=horizon*dt_sample:
                    J_loss[j_loss]  = j_loss
                    LOSS[i, j_loss] = loss_track
                    print('sample=', k, 'loss=', loss_track)
                    j_loss += 1

            r_I = output['r_I_new']
            euler = output['Euler_new']
            # Update time and state
            time += T_step
            a_I_new = a_I_next
            a_I_p += [a_I_new]
            print('learning=', i+1, 'time=', time, 'position', r_I.T, 'control=', np.sqrt(ctrl[-1].T), 'attitude', euler)
            # if j == (N-1):
                # Save the loss and training time
        Time_t += [i ]
        mean_loss = sum_loss / k
        mean_time = sum_time / k
        if i > 1 :
            delta_cost = abs(mean_loss - mean_loss0)
        mean_loss0 = mean_loss
        Loss += [mean_loss]
        grad_time += [mean_time]
        print('learned', i + 1, 'mean_loss=', mean_loss)
        np.save('Loss', Loss)
        np.save('Time_t', Time_t)
        np.save('Grad_time', grad_time)
        i = i+1
        Position += [position]
       
        Error += [error]


        # PATH1 = "Trained_model_QR.pt", leave options for joint-optimization with nerual networks
        # torch.save(model_QR, PATH1)
        # PATH2 = "Trained_model_gain.pt"
        # torch.save(model_gain, PATH2)

        np.save('LOSS', LOSS)
        np.save('J_loss', J_loss)
        np.save('tunable_para', tunable_para)
        np.save('Gamma1', Gamma1)
        np.save('Gamma2', Gamma2)
        np.save('Position_training', Position)
        np.save('Error_training', Error)


"""---------------------------------Evaluation process-----------------------------"""
def Evaluate():
    # Initial time
    time = 0
    Time = np.zeros(N_ev + 1)
    Time[0] = 0
    # Load trajectory data
    filename = 'waypoints'
    traj_waypoints = np.loadtxt(filename)
    # Initial weighting matrix of the arrival cost
    P0 = 100 * np.identity(uav.Xmhe_p.numel())
    # Initial states
    P_xy0 = np.random.normal(0, 0, 2)
    np.save('P_xy0', P_xy0)
    r_I0 = np.array([[P_xy0[0], P_xy0[1], 0]]).T
    state = np.vstack((r_I0, v_I0, R_Bv0, w_B0))
    x_hatmh = np.vstack((r_I0, v_I0, df_I0, R_Bv0, w_B0, dt_B0))
    xmhe_traj = x_hatmh
    R_Bd = R_Bd0
    dR_Bd = dR_Bd0
    # # Load the neural network model
    # PATH1 = "Trained_model_QR.pt"
    # model_QR = torch.load(PATH1)
    # PATH2 = "Trained_model_gain.pt"
    # model_gain = torch.load(PATH2)
    # Control force and torque list
    ctrl_f = []
    # Control list
    ctrl = []
    # Rotation list
    R_B = []
    # Reference list
    Ref = []
    # motor speed
    speed = []
    speed0 = np.sqrt(Sys_para[0]*9.8/(4*Sys_para[5]))*np.ones((4,1))
    speed += [speed0]
    # Measurement list
    Y = []
    # add measurement noise
    noise = np.random.normal(0, 1e-3, uav.X.numel())
    Noise = np.zeros((1, 18))
    for iN in range(18):
        Noise[0, iN] = noise[iN]
    state_m = state.T + Noise
    state_m = state_m.T
    # sample the measurement and ground truth
    y_p = state_m[0:6, 0]
    y_p = np.reshape(y_p, (6, 1))
    Y += [state_m]
    Y_p = []
    Y_p += [y_p]
    # Tracking error list
    track_e = []
    track_e += [np.zeros((10, 1))]
    # Initialize the tunable parameters
    # Initialize the reference trajectory
    kr = 0
    ref_p = np.array([[traj_waypoints[kr, 0], traj_waypoints[kr, 1], -traj_waypoints[kr, 2]]]).T
    ref_v = np.array([[traj_waypoints[kr, 3], traj_waypoints[kr, 4], -traj_waypoints[kr, 5]]]).T
    ref_dv = np.array([[traj_waypoints[kr, 6], traj_waypoints[kr, 7], -traj_waypoints[kr, 8]]]).T
    R_Bd_h = np.transpose(R_Bv0)
    w_Bd = w_B0
    ref_pva = np.vstack((ref_p, ref_v, np.transpose(R_Bd_h), w_Bd))
    ctrl_f0 = np.array([[0, 0, -Sys_para[0] * 9.81]]).T
    # input_nn_QR = np.vstack((Y[-1],speed[-1]))
    # Initialize the tunable parameters
    tunable_para = np.reshape(np.load('tunable_para.npy')[0], (1, 50))
    Tunable_para[0, :] = tunable_para
    print('learned', 0, 'tunable_para0=', Tunable_para[0, :])

    # Set initial disturbance
    ctrl0 = np.zeros((4, 1))
    payload_mass = np.array([0.5])
    a_I_p = []
    a_I_new = np.zeros((3, 1))
    for ia in range(15):
        a_I_p += [a_I_new]
    a_noise = np.random.normal(0, 1e-3, 3)
    # dis0 = uav.Aerodynamics(state, a_I_p[-3], ctrl0, constant_dis, a_noise, payload_mass, None)

    aero_para = np.zeros((6,1))#np.array([[dfxy[0], dfxy[1], dfz[0], dt[0], dt[1], dt[2]]]).T
    
    dis0 = uav.Aerodynamics(state, np.zeros((4,1)), aero_para)
    # Store initial conditions
    r_Is[:, 0:1] = r_I0
    p_Is[:, 0:1] = p_I0
    v_Is[:, 0:1] = v_I0
    Euler[:, 0:1] = Euler_0
    w_Bs[:, 0:1] = w_B0
    Dis_t[:, 0:1] = dis0
    Df_Imh[:, 0:1] = df_I0
    Dt_Bmh[:, 0:1] = dt_B0
    D_G[:, 0:1] = dis0
    # Flag for breaking the episode
    flag = 0
    # Index for sampling
    k = 0
    time_s = 0
    Time_s = np.zeros((int(N_ev /ratio_inv) + 1))
    Time_s[0] = time_s
    # Store altitude tracking error
    eZ = np.zeros((int(N_ev/ratio_inv) + 1))
    eX = np.zeros((int(N_ev / ratio_inv) + 1))
    eY = np.zeros((int(N_ev / ratio_inv) + 1))
    eaZ = np.zeros((int(N_ev/ratio_inv) + 1))
    eZ[0] = 0
    eX[0] = 0
    eY[0] = 0
    eaZ[0] = 0
    # Store position
    ref_x = np.zeros((int(N_ev/ratio_inv) + 1))
    ref_y = np.zeros((int(N_ev/ratio_inv) + 1))
    ref_z = np.zeros((int(N_ev / ratio_inv) + 1))
    act_x = np.zeros((int(N_ev/ratio_inv) + 1))
    act_y = np.zeros((int(N_ev/ratio_inv) + 1))
    act_z = np.zeros((int(N_ev / ratio_inv) + 1))
    ref_x[0] = 0
    ref_y[0] = 0
    ref_z[0] = 0
    act_x[0] = 0
    act_y[0] = 0
    act_z[0] = 0
    # open a file
    a_file = open("flight_test.txt", "w")
    dR_lp = np.zeros((3, 3))
    ddR_lp = np.zeros((3, 3))
    # Sum of loss
    sum_loss = 0.0
    # Sum of time
    sum_time = 0.0

    for j in range(N_ev):
        if j % 8 == 0:
            if kr <= (np.size(traj_waypoints, 0) - 1):
                ref_p = np.array([[traj_waypoints[kr, 0], traj_waypoints[kr, 1], -traj_waypoints[kr, 2]]]).T
                ref_v = np.array([[traj_waypoints[kr, 3], traj_waypoints[kr, 4], -traj_waypoints[kr, 5]]]).T
                ref_dv = np.array([[traj_waypoints[kr, 6], traj_waypoints[kr, 7], -traj_waypoints[kr, 8]]]).T
                ref_pva  = np.vstack((ref_p, ref_v, np.transpose(R_Bd_h), w_Bd))
                b1_d = np.array([[1, 0, 0]]).T
            else:
                ref_p = np.array([[traj_waypoints[-1, 0], traj_waypoints[-1, 1], -traj_waypoints[-1, 2]]]).T
                ref_v = np.array([[traj_waypoints[-1, 3], traj_waypoints[-1, 4], -traj_waypoints[-1, 5]]]).T
                ref_dv = np.array([[traj_waypoints[-1, 6], traj_waypoints[-1, 7], -traj_waypoints[-1, 8]]]).T
                ref_pva  = np.vstack((ref_p, ref_v, np.transpose(R_Bd_h), w_Bd))
                b1_d = np.array([[1, 0, 0]]).T
            kr +=1
        # Coeff_x, Coeff_y, Coeff_z = polynomial_ref(t_end, target, P_xy0)
        # ref = Reference(Coeff_x, Coeff_y, Coeff_z, time, t_end, target)
        # ref_p, ref_v, ref_dv, b1_d = ref['ref_p'], ref['ref_v'], ref['ref_a'], ref['b1_d']
        ref_pva = np.vstack((ref_p, ref_v, np.transpose(R_Bd_h), w_Bd))
        if (j % ratio_inv) == 0:
            # Solve MHE to obtain the estimated state trajectory within a horizon
            opt_sol = uavMHE.MHEsolver(Y, x_hatmh, xmhe_traj, ctrl, tunable_para, k, speed)
            xmhe_traj = opt_sol['state_traj_opt']
            costate_traj = opt_sol['costate_traj_opt']
            noise_traj = opt_sol['noise_traj_opt']
            # Establish the auxiliary MHE system
            auxSys = uavMHE.GetAuxSys(xmhe_traj, costate_traj, noise_traj, tunable_para, Y, ctrl, speed)
            matA, matB, matH = auxSys['matA'], auxSys['matB'], auxSys['matH']
            matD, matE, matF = auxSys['matD'], auxSys['matE'], auxSys['matF']
            matG             = auxSys['matG']
            # Solve the auxiliary MHE system to obtain the gradient
            start_time = TM.time()
            gra_opt = uavDMHE.AuxMHESolver(matA, matB, matD, matE, matF, matH, matG, tunable_para, Y, speed)
            gradtime = TM.time() - start_time
            print("--- %s seconds ---" % gradtime)
            sum_time += gradtime
            X_opt = gra_opt['state_gra_traj']
            if time > (horizon * dt_sample):
                # Update x_hatmh based on xmhe_traj
                for ix in range(len(x_hatmh)):
                    x_hatmh[ix] = xmhe_traj[1, ix]
            else:
                for ix in range(len(x_hatmh)):
                    x_hatmh[ix] = xmhe_traj[0, ix]

            # Position control
            df_Imh = np.transpose(xmhe_traj[-1, 6:9])
            df_Imh = np.reshape(df_Imh, (3, 1))
            dt_Bmh = np.transpose(xmhe_traj[-1, 21:24])
            dt_Bmh = np.reshape(dt_Bmh, (3, 1))
            # df_Imh = np.zeros((3,1))
            # dt_Bmh = np.zeros((3,1))

            ctrl_gain = np.array([[30, 22, 21, 9, 9, 9, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2]])
            
            print('sample=', k, 'p1=', tunable_para[0, 0], 'gamma1=', tunable_para[0, 24], 'r1=', tunable_para[0, 25],
                  'gamma2=', tunable_para[0, 43], 'q1=', tunable_para[0, 44], 'ref.x=', ref_p.T[0, 0], 'ref.z=',
                  ref_p.T[0, 2])
            feedback = np.hstack((xmhe_traj[-1,0:6], xmhe_traj[-1,9:21]))
            feedback = np.reshape(feedback, (18, 1))
            R_Bd_next, Tf, e_x, e_v, fd = GeoCtrl.position_ctrl(ctrl_gain, feedback, ref_p, ref_v, ref_dv, b1_d, df_Imh)
            dR_Bd_nolp = (R_Bd_next - R_Bd) / dt_sample
            R_Bd = R_Bd_next  # update R_Bd0 for computing dR_Bd in the next iteration
            dR_Bd_next = (dR_Bd_nolp + (tau / dt_sample) * dR_lp) / (1 + tau / dt_sample)
            # dR_Bd_next = dR_Bd_nolp
            dR_lp = dR_Bd_next
            ddR_Bd_nolp = (dR_Bd_next - dR_Bd) / dt_sample
            dR_Bd = dR_Bd_next
            ddR_Bd_next = (ddR_Bd_nolp + (tau / dt_sample) * ddR_lp) / (1 + tau / dt_sample)
            ddR_lp = ddR_Bd_next
            # ddR_Bd_next = ddR_Bd_nolp
            DR_Bd_next = np.zeros((3, 3))
            DDR_Bd_next = np.zeros((3, 3))
            for ir in range(3):
                for jr in range(3):
                    DR_Bd_next[ir, jr] = dR_Bd_next[ir, jr]
            for ir in range(3):
                for jr in range(3):
                    DDR_Bd_next[ir, jr] = ddR_Bd_next[ir, jr]
            # Attitude control
            tau_c, w_Bd, e_R, e_w, error_func = GeoCtrl.attitude_ctrl(DR_Bd_next, DDR_Bd_next, dt_Bmh)

            # Map the control force and torque to the square of the rotor speed
            u = GeoCtrl.ctrl_mapping(Tf, tau_c)
            # Limit the rotor speed
            u = np.clip(u, U_lower, U_upper)

            # Store tracking error
            error_track = np.vstack((e_x, e_v, error_func, e_w))
            track_e += [error_track]
            # Ctrl_Gain += [ctrl_gain]
            speed += [np.sqrt(u) / u_max]
            # # Map the control force and torque to the square of the rotor speed
            # u = GeoCtrl.ctrl_mapping(Tf, tau_c)
            # # Limit the rotor speed
            # u = np.clip(u, U_lower, U_upper)
            ctrl += [u]
            ctrl_f += [fd]
            # save fd and b1_d into txt. file
            save_data = np.hstack((fd.T, b1_d.T))
            np.savetxt(a_file, save_data)
            # Store the rotation
            R_bc = np.array([
                [Y[-1][6, 0], Y[-1][7, 0], Y[-1][8, 0]],
                [Y[-1][9, 0], Y[-1][10, 0], Y[-1][11, 0]],
                [Y[-1][12, 0], Y[-1][13, 0], Y[-1][14, 0]]]
            )
            R_B += [R_bc]
            # Store the reference
            R_Bd_h = np.array([[R_Bd[0, 0], R_Bd[0, 1], R_Bd[0, 2],
                                R_Bd[1, 0], R_Bd[1, 1], R_Bd[1, 2],
                                R_Bd[2, 0], R_Bd[2, 1], R_Bd[2, 2]]])
            ref = np.hstack((np.transpose(ref_p), np.transpose(ref_v), R_Bd_h, np.transpose(w_Bd)))
            Ref += [ref]
            print('b1d=',np.array([[R_Bd[0, 0],R_Bd[1, 0],R_Bd[2, 0]]]), 'b3_d=',np.array([[R_Bd[0, 2],R_Bd[1, 2],R_Bd[2, 2]]]))

        if time <=2:
            noise = np.random.normal(0, 0.1, 1)
            aero_para = np.array([[0.2+0.1*noise[0], 0.2+0.1*noise[0], 1*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0]]]).T
        elif time<=4 and time>2:
            noise = np.random.normal(0, 0.1, 1)
            aero_para = -np.array([[0.2+0.1*noise[0], 0.2+0.1*noise[0], 1*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0]]]).T

        elif time <= 8 and time >= 4:
            noise = np.random.normal(0, 0.1, 1)
            aero_para = 1 * np.array([[0.25 * math.sin(0.5 * math.pi * time) + 0.25 * noise[0],
                                           0.25 * math.sin(0.5 * math.pi * time) + 0.25 * noise[0],
                                           2 * math.sin(0.5 * math.pi * time) + 1 * noise[0],
                                           0.05 * math.sin(0.5 * math.pi * time) + 0.02 * noise[0],
                                           0.05 * math.sin(0.5 * math.pi * time) + 0.02 * noise[0],
                                           0.01 * math.sin(0.5 * math.pi * time) + 0.01 * noise[0]]]).T
        elif time <= 12 and time > 8:
            noise = np.random.normal(0, 0.1, 1)
            aero_para = 2 * np.array([[0.25 * math.sin(0.5 * math.pi * time) + 0.25 * noise[0],
                                           0.25 * math.sin(0.5 * math.pi * time) + 0.25 * noise[0],
                                           2 * math.sin(0.5 * math.pi * time) + 1 * noise[0],
                                           0.05 * math.sin(0.5 * math.pi * time) + 0.02 * noise[0],
                                           0.05 * math.sin(0.5 * math.pi * time) + 0.02 * noise[0],
                                           0.01 * math.sin(0.5 * math.pi * time) + 0.008 * noise[0]]]).T
        elif time<=14 and time>12:
            noise = np.random.normal(0, 0.1, 1)
            aero_para = np.array([[0.2+0.1*noise[0], 0.2+0.1*noise[0], 6+2*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0]]]).T
        elif time<=16 and time>14:
            noise = np.random.normal(0, 0.05, 1)
            aero_para = -np.array([[0.2+0.1*noise[0], 0.2+0.1*noise[0], 2+2*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0]]]).T
        # elif time<=15 and time>14:
        #     noise = np.random.normal(0, 0.1, 1)
        #     aero_para = np.array([[0.2+0.1*noise[0], 0.2+0.1*noise[0], 6+2*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0], 0.05+0.05*noise[0]]]).T
        else:
            aero_para = np.zeros((6, 1))

        dis = uav.Aerodynamics(state, ctrl[-1], aero_para)
        # Store disturbance ground truth
        D_G[:, (j+1):(j+2)] = dis
        print('sample=', k, 'Dis=', dis[2, 0], 'df_Imh=', df_Imh[2, 0], 'Dis_t=', dis[3, 0], 'dt_Bmh=', dt_Bmh[0, 0])
        zeros_rotor = np.where(ctrl[-1] == 0)[0]
        if np.size(zeros_rotor) >= 2:
            flag += 1
        else:
            flag = 0
        if flag >= 20:
            break
        output = uav.step(state, ctrl[-1], dis, T_step)
        # Update state
        state_next = output['state_new']
        a_I_next = output['a_I_new']
        if (j % ratio_inv) == 0:
            # Take measurement
            noise = np.random.normal(0, 1e-3, uav.X.numel())
            Noise = np.zeros((1, 18))
            for iN in range(18):
                Noise[0, iN] = noise[iN]
            state_m = state.T + Noise
            state_m = state_m.T
            # sample the measurement and ground truth
            y_p = state_m[0:6, 0]
            y_p = np.reshape(y_p, (6, 1))
            Y += [state_m]
            Y_p += [y_p]
            # Update sampling index, time and tunable_para
            k += 1
            time_s += dt_sample
            Time_s[k] = time_s

            # compute loss
            dp, loss_track = uavDMHE.ChainRule(Ref, xmhe_traj,X_opt)
            # Sum the loss
            loss_track = np.reshape(loss_track, (1))
            sum_loss += loss_track
            # Store loss function and estimated disturbance
            Df_Imh[:, k:(k + 1)] = df_Imh
            Dt_Bmh[:, k:(k + 1)] = dt_Bmh
            Dis_t[:, k:(k + 1)] = dis
            eZ[k] = ref_p[2, 0] - state[2, 0]
            eX[k] = ref_p[0,0] - state[0,0]
            eY[k] = ref_p[1,0] - state[1,0]
            eaZ[k] = error_func
            ref_x[k] = ref_p[0, 0]
            ref_y[k] = ref_p[1, 0]
            ref_z[k] = ref_p[2, 0]
            act_x[k] = state[0, 0]
            act_y[k] = state[1, 0]
            act_z[k] = state[2, 0]

        r_I = output['r_I_new']
        v_I = output['v_I_new']
        euler = output['Euler_new']
        w_B = output['w_B_new']
        r_Is[:, (j + 1):(j + 2)] = r_I #(j + 1):(j + 2)
        v_Is[:, (j + 1):(j + 2)] = v_I
        Euler[:, (j + 1):(j + 2)] = euler
        w_Bs[:, (j + 1):(j + 2)] = w_B
        # Update time and state
        time += T_step
        state = state_next
        a_I_new = a_I_next
        a_I_p += [a_I_new]
        Time[j + 1] = time
        print('time=', time, 'sample=', k, 'position=', r_I.T, 'control=', np.sqrt(ctrl[-1].T), 'attitude', euler)
        print('sample=', k, 'p1=', tunable_para[0, 0], 'gamma1=', tunable_para[0, 24], 'r3=', tunable_para[0, 27],
              'gamma2=', tunable_para[0, 43], 'q1=', tunable_para[0, 44], 'ref.x=', ref_p.T[0, 0], 'ref.z=',
              ref_p.T[0, 2])
    mean_loss_ev = (sum_loss) / k
    mean_time    = sum_time / k
    print('mean_loss_ev=', mean_loss_ev)
    print('mean_time=', mean_time)
    np.save('mean_time', mean_time)
    print('tunable_para=', tunable_para)
    np.save('mloss_ev', mean_loss_ev)
    np.save('Dis_t', Dis_t)
    np.save('D_G', D_G)
    np.save('r_Is', r_Is)
    np.save('Df_Imh', Df_Imh)
    np.save('Dt_Bmh', Dt_Bmh)
    np.save('Time_s', Time_s)
    np.save('eZ', eZ)
    np.save('eX',eX)
    np.save('eY',eY)
    np.save('eaZ', eaZ)
    np.save('control_gain', Control_gain)
    np.save('ref_x', ref_x)
    np.save('ref_y', ref_y)
    np.save('ref_z', ref_z)
    np.save('act_x', act_x)
    np.save('act_y', act_y)
    np.save('act_z', act_z)
    a_file.close()


    """
    Plot figures
    """
    # Loss function

    Loss = np.load('Loss.npy')
    Gamma1 = np.load('Gamma1.npy')
    Gamma2 = np.load('Gamma2.npy')
    Time_t = []
    for it in range (Loss.size):
        Time_t += [it]
    plt.figure(1)
    plt.plot(Time_t, Loss, linewidth=1.5, marker='o')
    plt.xlabel('Number of episodes')
    plt.ylabel('Mean loss')
    plt.grid()
    plt.savefig('./mean_loss_train.png')
    plt.show()
    # # Loss for each episode
    # jloss = np.load('J_loss.npy')
    # loss_ep = np.load('LOSS.npy')
    # plt.figure(2)
    # plt.plot(jloss, loss_ep[-1, :], linewidth=1.5)
    # plt.xlabel('Times')
    # plt.ylabel('Loss for the last training')
    # plt.grid()
    # plt.savefig('./loss_train.png')
    # plt.show()
    # Disturbance
    plt.figure(2)
    plt.plot(Time_s, Dis_t[0, :], linewidth=1, linestyle='--')
    plt.plot(Time_s, Df_Imh[0, :], linewidth=1.5)
    plt.xlabel('Time [s]')
    plt.ylabel('Disturbance force in x axis')
    plt.legend(['Ground truth', 'MHE estimation'])
    plt.grid()
    plt.savefig('./disturbance_x.png')
    plt.show()
    plt.figure(3)
    plt.plot(Time_s, Dis_t[2, :], linewidth=1, linestyle='--')
    plt.plot(Time_s, Df_Imh[2, :], linewidth=1.5)
    plt.xlabel('Time [s]')
    plt.ylabel('Disturbance force in z axis')
    plt.legend(['Ground truth', 'MHE estimation'])
    plt.grid()
    plt.savefig('./disturbance.png')
    plt.show()

    # Disturbance torque
    plt.figure(4)
    plt.plot(Time_s, Dis_t[3, :], linewidth=1, linestyle='--')
    plt.plot(Time_s, Dt_Bmh[0, :], linewidth=1.5)
    plt.xlabel('Time [s]')
    plt.ylabel('Disturbance torque in x axis')
    plt.legend(['Ground truth', 'MHE estimation'])
    plt.grid()
    plt.savefig('./dis_torque.png')
    plt.show()
    plt.figure(5)
    plt.plot(Time_s, Dis_t[5, :], linewidth=1, linestyle='--')
    plt.plot(Time_s, Dt_Bmh[2, :], linewidth=1.5)
    plt.xlabel('Time [s]')
    plt.ylabel('Disturbance torque in z axis')
    plt.legend(['Ground truth', 'MHE estimation'])
    plt.grid()
    plt.savefig('./dis_torque_z.png')
    plt.show()

    # Trajectory
    plt.figure(6)
    ax = plt.axes(projection="3d")
    ax.plot3D(act_x, act_y, -act_z, linewidth=1.5)
    ax.plot3D(ref_x, ref_y, -ref_z, linewidth=1, linestyle='--')
    plt.legend(['Actual', 'Desired'])
    plt.xlabel('x [m]')
    plt.ylabel('y [m]')
    # plt.zlabel('z [m]')
    plt.grid()
    plt.savefig('./tracking_3D.png')
    plt.show()

    plt.figure(7)
    plt.plot(act_x, act_y, linewidth=1.5)
    plt.plot(ref_x, ref_y, linewidth=1, linestyle='--')
    plt.legend(['Actual', 'Desired'])
    plt.xlabel('x [m]')
    plt.ylabel('y [m]')
    plt.grid()
    plt.savefig('./tracking_2D.png')
    plt.show()
    # Altitude tracking error
    plt.figure(8)
    plt.plot(Time_s, eZ, linewidth=1.5)
    plt.xlabel('time [s]')
    plt.ylabel('ez [m]')
    plt.grid()
    plt.savefig('./tracking_error_z.png')
    plt.show()
    plt.figure(9)
    plt.plot(Time_s, eX, linewidth=1.5)
    plt.xlabel('time [s]')
    plt.ylabel('ex [m]')
    plt.grid()
    plt.savefig('./tracking_error_x.png')
    plt.show()
    plt.figure(10)
    plt.plot(Time_s, eY, linewidth=1.5)
    plt.xlabel('time [s]')
    plt.ylabel('ey [m]')
    plt.grid()
    plt.savefig('./tracking_error_y.png')
    plt.show()
    # Attitude tracking error
    plt.figure(11)
    plt.plot(Time_s, eaZ, linewidth=1.5)
    plt.xlabel('time [s]')
    plt.ylabel('eaz [m]')
    plt.grid()
    plt.savefig('./tracking_attitude_error.png')
    plt.show()
    # gamma
    plt.figure(12)
    plt.plot(Gamma1, linewidth=1)
    plt.plot(Gamma2, linewidth=0.5)
    plt.xlabel('iteration')
    plt.ylabel('forgetting factor')
    plt.grid()
    plt.savefig('./gamma.png')
    plt.show()


"""---------------------------------Main function-----------------------------"""
if train:
    Train(tunable_para0)
    Evaluate()
else:
    Evaluate()